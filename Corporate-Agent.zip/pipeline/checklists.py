# pipeline/checklists.py
# Expanded checklist + detection for multiple document categories

REQUIRED_DOCS = {
    "Company Formation": [
        "Articles of Association (AoA)",
        "Memorandum of Association (MoA/MoU)",
        "Board Resolution",
        "Shareholder Resolution",
        "Incorporation Application Form",
        "UBO Declaration Form",
        "Register of Members and Directors",
        "Change of Registered Address Notice"
    ],
    "Licensing & Regulatory Filings": [
        "Trade License Application",
        "Regulatory Approval Form",
        "Renewal Application",
        "Annual Return Filing",
        "Financial Statements"
    ],
    "Employment & HR Contracts": [
        "Employment Contract",
        "Offer Letter",
        "Non-Disclosure Agreement (NDA)",
        "Employee Handbook / Policies",
        "Termination Notice"
    ],
    "Commercial Agreements": [
        "Service Agreement",
        "Consultancy Agreement",
        "Sales Contract",
        "Partnership Agreement",
        "Non-Compete Agreement"
    ],
    "Compliance & Risk Policies": [
        "Anti-Money Laundering Policy",
        "Data Protection Policy",
        "Risk Management Framework",
        "Code of Conduct",
        "Whistleblower Policy"
    ]
}


def detect_document_types(paragraphs):
    """
    Simple keyword-based detection.
    Returns (detected_docs: list, inferred_process: str)
    """
    text = "\n".join(paragraphs).lower()
    detected = []

    # --- Company Formation ---
    if "articles of association" in text or "aoa" in text:
        detected.append("Articles of Association (AoA)")
    if "memorandum of association" in text or "moa" in text or "mou" in text:
        detected.append("Memorandum of Association (MoA/MoU)")
    if "board resolution" in text:
        detected.append("Board Resolution")
    if "shareholder resolution" in text:
        detected.append("Shareholder Resolution")
    if "incorporation form" in text or "application for incorporation" in text:
        detected.append("Incorporation Application Form")
    if "ultimate beneficial owner" in text or "ubo" in text:
        detected.append("UBO Declaration Form")
    if "register of members" in text or "register of directors" in text:
        detected.append("Register of Members and Directors")
    if "change of registered address" in text:
        detected.append("Change of Registered Address Notice")

    # --- Licensing & Regulatory Filings ---
    if "trade license" in text:
        detected.append("Trade License Application")
    if "regulatory approval" in text:
        detected.append("Regulatory Approval Form")
    if "renewal application" in text:
        detected.append("Renewal Application")
    if "annual return" in text:
        detected.append("Annual Return Filing")
    if "financial statements" in text:
        detected.append("Financial Statements")

    # --- Employment & HR Contracts ---
    if "employment contract" in text:
        detected.append("Employment Contract")
    if "offer letter" in text:
        detected.append("Offer Letter")
    if "non-disclosure agreement" in text or "nda" in text:
        detected.append("Non-Disclosure Agreement (NDA)")
    if "employee handbook" in text or "policies" in text:
        detected.append("Employee Handbook / Policies")
    if "termination notice" in text:
        detected.append("Termination Notice")

    # --- Commercial Agreements ---
    if "service agreement" in text:
        detected.append("Service Agreement")
    if "consultancy agreement" in text:
        detected.append("Consultancy Agreement")
    if "sales contract" in text:
        detected.append("Sales Contract")
    if "partnership agreement" in text:
        detected.append("Partnership Agreement")
    if "non-compete agreement" in text:
        detected.append("Non-Compete Agreement")

    # --- Compliance & Risk Policies ---
    if "anti-money laundering" in text or "aml policy" in text:
        detected.append("Anti-Money Laundering Policy")
    if "data protection policy" in text or "privacy policy" in text:
        detected.append("Data Protection Policy")
    if "risk management" in text:
        detected.append("Risk Management Framework")
    if "code of conduct" in text:
        detected.append("Code of Conduct")
    if "whistleblower policy" in text:
        detected.append("Whistleblower Policy")

    # --- Infer process ---
    process = "Unknown"
    if any(doc in detected for doc in REQUIRED_DOCS["Company Formation"]):
        process = "Company Formation"
    elif any(doc in detected for doc in REQUIRED_DOCS["Licensing & Regulatory Filings"]):
        process = "Licensing & Regulatory Filings"
    elif any(doc in detected for doc in REQUIRED_DOCS["Employment & HR Contracts"]):
        process = "Employment & HR Contracts"
    elif any(doc in detected for doc in REQUIRED_DOCS["Commercial Agreements"]):
        process = "Commercial Agreements"
    elif any(doc in detected for doc in REQUIRED_DOCS["Compliance & Risk Policies"]):
        process = "Compliance & Risk Policies"

    return detected, process


def checklist_verification(detected_docs, inferred_process):
    """
    Compare uploaded documents against required checklist for the inferred legal process.

    Args:
        detected_docs (list): List of detected document names.
        inferred_process (str): The legal process inferred from documents.

    Returns:
        tuple:
            required_docs (list): List of required documents for the process.
            missing_docs (list): List of required documents missing from detected_docs.
    """
    required_docs = REQUIRED_DOCS.get(inferred_process, [])
    missing_docs = [doc for doc in required_docs if doc not in detected_docs]
    return required_docs, missing_docs
