from docx import Document


def read_docx(path):
    """Return (paragraphs:list[str], tables:list[list[list[str]]], full_text:str)"""
    doc = Document(path)
    paras = [p.text.strip() for p in doc.paragraphs if p.text and p.text.strip()]
    tables = []
    for t in doc.tables:
        rows = []
        for r in t.rows:
            cells = [c.text.strip() for c in r.cells]
            rows.append(cells)
        tables.append(rows)
    full_text = "\n".join(paras)
    return paras, tables, full_text