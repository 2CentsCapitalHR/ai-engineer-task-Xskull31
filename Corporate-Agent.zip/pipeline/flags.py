# pipeline/flags.py
import re
from rag.retriever import retrieve_passages
from utils.llm_client import check_clause_with_llm
import json

def find_issues(full_text, paragraphs, rag_enabled=True):
    """
    Return list of issue dicts:
    {section, issue, severity, suggestion, citations}
    """
    issues = []
    text = full_text.lower()

    # --- 1) Rule-based red flags ---
    # Jurisdiction mismatch
    if ("federal court" in text or "u.a.e. court" in text or "uae courts" in text) and "adgm" not in text:
        issues.append({
            "section": "Jurisdiction Clause",
            "issue": "Potential jurisdiction mismatch — references federal/UAE courts instead of ADGM",
            "severity": "High",
            "suggestion": "Replace with 'ADGM Courts' per ADGM Companies Regulations.",
            "citations": []
        })

    # Missing signature block
    if not re.search(r"sign(ed)? by|signature|signed:\s", text):
        issues.append({
            "section": "Execution / Signature",
            "issue": "No explicit signature block or 'signed by' detected",
            "severity": "Medium",
            "suggestion": "Add an execution block with signatory name, capacity, and date.",
            "citations": []
        })

    # Missing effective date
    if not re.search(r"effective date|effective from|dated:\s", text):
        issues.append({
            "section": "Effective Date",
            "issue": "No explicit effective date found",
            "severity": "Low",
            "suggestion": "Include a clause stating when the agreement comes into force.",
            "citations": []
        })

    # Too short document
    if len(paragraphs) < 3:
        issues.append({
            "section": "Document Length",
            "issue": "Document appears very short; may be incomplete",
            "severity": "Low",
            "suggestion": "Verify that the uploaded file is the complete document.",
            "citations": []
        })

    # --- 2) LLM+RAG compliance checks ---
    if rag_enabled:
        for para in paragraphs:
            if len(para.split()) < 6:  # skip very short paras
                continue

            retrieved = retrieve_passages(para, top_k=2)
            if retrieved:
                llm_result_raw = check_clause_with_llm(para, retrieved)
                try:
                    llm_result = json.loads(llm_result_raw) if isinstance(llm_result_raw, str) else llm_result_raw
                except json.JSONDecodeError:
                    llm_result = {}

                if llm_result and not llm_result.get("compliant", True):
                    issues.append({
                        "section": "LLM Compliance Check",
                        "issue": llm_result.get("reason", "Potential non-compliance"),
                        "severity": llm_result.get("severity", "Medium"),
                        "suggestion": llm_result.get("suggestion", ""),
                        "citations": llm_result.get("citations", [])
                    })

    return issues
