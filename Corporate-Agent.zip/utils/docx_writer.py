# utils/docx_writer.py
from docx import Document
from docx.shared import Pt


def append_review(input_path, issues, output_path):
    """Append a 'REVIEW SUMMARY' section at the end of the docx with issues + citations."""
    doc = Document(input_path)

    # Add page break then heading
    doc.add_page_break()
    heading = doc.add_paragraph()
    run = heading.add_run("REVIEW SUMMARY (Automated)")
    run.bold = True
    run.font.size = Pt(14)

    if not issues:
        doc.add_paragraph("No issues detected by the automated checks.")
    else:
        for i, it in enumerate(issues, start=1):
            p = doc.add_paragraph(f"{i}. Section: {it.get('section')} — Issue: {it.get('issue')}")
            if it.get("suggestion"):
                doc.add_paragraph(f"   Suggestion: {it['suggestion']}")
            if it.get("severity"):
                doc.add_paragraph(f"   Severity: {it['severity']}")
            if it.get("citations"):
                doc.add_paragraph("   Citations:")
                for c in it["citations"]:
                    doc.add_paragraph(f"     - {c}", style="List Bullet")

    doc.save(output_path)
