# utils/llm_client.py
import requests
import os

# Read from .env or fallback defaults
LLM_MODEL = os.getenv("LLM_MODEL", "mistral")

def check_clause_with_llm(clause_text, retrieved_passages):
    """
    clause_text: str - clause from document
    retrieved_passages: list of (text, metadata) from retriever
    Returns: str - LLM JSON output as string
    """
    context_text = "\n\n".join(
        [f"Source: {meta.get('source','unknown')}\n{text}" for text, meta in retrieved_passages]
    )

    prompt = f"""
You are a legal compliance assistant checking clauses against ADGM regulations.

Clause to check:
{clause_text}

Relevant ADGM regulatory text:
{context_text}

Task:
1. Is the clause compliant? Answer Yes/No.
2. If not compliant, explain why.
3. Suggest a corrected clause that would make it compliant.
4. Cite exact ADGM source(s) with article/page.

Return in JSON format:
{{
  "verdict": "...",
  "reason": "...",
  "suggestion": "...",
  "citations": ["..."]
}}
"""

    r = requests.post(
        "http://localhost:11434/api/generate",
        json={"model": LLM_MODEL, "prompt": prompt, "stream": False}
    )
    r.raise_for_status()
    return r.json().get("response", "")
