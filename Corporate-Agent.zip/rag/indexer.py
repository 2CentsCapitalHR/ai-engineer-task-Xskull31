# rag/indexer.py
from pathlib import Path
from sentence_transformers import SentenceTransformer
import faiss
import json
import numpy as np
import os
import math

TEXT_DIR = Path("rag/text")
INDEX_DIR = Path("rag/index")
MODEL_NAME = "all-MiniLM-L6-v2"  # small & fast
CHUNK_SIZE = 400  # characters
CHUNK_OVERLAP = 50

def chunk_text(text, size=CHUNK_SIZE, overlap=CHUNK_OVERLAP):
    text = text.replace("\r\n", "\n")
    chunks = []
    i = 0
    L = len(text)
    while i < L:
        chunk = text[i:i+size]
        chunks.append(chunk.strip())
        i += size - overlap
    return [c for c in chunks if c]

def build_index():
    INDEX_DIR.mkdir(parents=True, exist_ok=True)
    model = SentenceTransformer(MODEL_NAME)
    texts = []
    metadatas = []
    for txtfile in TEXT_DIR.glob("*.txt"):
        src = txtfile.name
        txt = txtfile.read_text(encoding="utf-8")
        for i, chunk in enumerate(chunk_text(txt)):
            texts.append(chunk)
            metadatas.append({"source_file": src, "chunk_id": i, "origin_path": str(txtfile)})
    if not texts:
        print("No texts found to index.")
        return

    embeddings = model.encode(texts, show_progress_bar=True, convert_to_numpy=True)
    dim = embeddings.shape[1]
    index = faiss.IndexFlatL2(dim)
    index.add(embeddings)
    faiss.write_index(index, str(INDEX_DIR / "index.faiss"))

    # save metadata
    with open(INDEX_DIR / "metadata.jsonl", "w", encoding="utf-8") as f:
        for m in metadatas:
            f.write(json.dumps(m, ensure_ascii=False) + "\n")

    # save texts (chunks)
    with open(INDEX_DIR / "texts.json", "w", encoding="utf-8") as f:
        json.dump(texts, f, ensure_ascii=False, indent=2)

    print(f"Indexed {len(texts)} chunks into {INDEX_DIR}")

if __name__ == "__main__":
    build_index()
