import os
import json
import faiss
from sentence_transformers import SentenceTransformer
import numpy as np

INDEX_DIR = os.path.join("rag", "index")
FAISS_INDEX_FILE = os.path.join(INDEX_DIR, "index.faiss")       # updated
METADATA_FILE = os.path.join(INDEX_DIR, "metadata.jsonl")       # updated
TEXTS_FILE = os.path.join(INDEX_DIR, "texts.json")              # assumed correct

model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")

def load_jsonl(file_path):
    with open(file_path, "r", encoding="utf-8") as f:
        return [json.loads(line) for line in f]

def load_index():
    if not (os.path.exists(FAISS_INDEX_FILE) and os.path.exists(METADATA_FILE) and os.path.exists(TEXTS_FILE)):
        raise FileNotFoundError("FAISS index or metadata/text files not found. Please run rag/indexer.py first.")

    index = faiss.read_index(FAISS_INDEX_FILE)
    metadata = load_jsonl(METADATA_FILE)
    with open(TEXTS_FILE, "r", encoding="utf-8") as f:
        texts = json.load(f)
    return index, texts, metadata

def retrieve_passages(query, top_k=3):
    index, texts, metadata = load_index()
    query_emb = model.encode([query])
    query_emb = np.array(query_emb).astype('float32')
    faiss.normalize_L2(query_emb)  # normalize query to match indexing
    distances, indices = index.search(query_emb, top_k)
    results = []
    for idx in indices[0]:
        if idx < 0 or idx >= len(texts):
            continue
        results.append((texts[idx], metadata[idx]))
    return results

if __name__ == "__main__":
    test_query = "The agreement shall be governed by UAE Federal Courts."
    for text, meta in retrieve_passages(test_query, top_k=3):
        print("----")
        print(f"Source: {meta.get('source', 'unknown')}")
        print(text)
