import sys
from rag.retriever import retrieve_passages
from utils.llm_client import run_llm_check

def main():
    if len(sys.argv) < 2:
        print("Usage: python rag/test_compliance.py 'Clause text here'")
        return

    clause_text = sys.argv[1]

    # Step 1 — Retrieve top 3 passages from ADGM index
    passages = retrieve_passages(clause_text)

    print("\n=== Retrieved ADGM Passages ===")
    for i, p in enumerate(passages, 1):
        text, meta = p
        print(f"[{i}] {text} (source: {meta.get('source_file', 'unknown')})")

    # Step 2 — Run LLM compliance check
    result = run_llm_check(clause_text, passages)

    print("\n=== LLM Compliance Check ===")
    print(result)

if __name__ == "__main__":
    main()
