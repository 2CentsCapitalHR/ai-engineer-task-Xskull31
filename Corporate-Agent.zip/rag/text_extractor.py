# rag/text_extractor.py
import os
from pathlib import Path
from PyPDF2 import PdfReader
from docx import Document

RAW_DIR = Path(__file__).parent / "raw"
TEXT_DIR = Path(__file__).parent / "text"

def extract_text_from_pdf(pdf_path: Path) -> str:
    """Extract clean text from PDF file."""
    try:
        reader = PdfReader(str(pdf_path))
        text_chunks = []
        for page in reader.pages:
            page_text = page.extract_text() or ""
            page_text = page_text.strip()
            if page_text:
                text_chunks.append(page_text)
        return "\n\n".join(text_chunks)
    except Exception as e:
        print(f"[ERROR] Failed to extract PDF {pdf_path}: {e}")
        return ""

def extract_text_from_docx(docx_path: Path) -> str:
    """Extract clean text from DOCX file."""
    try:
        doc = Document(str(docx_path))
        paras = [p.text.strip() for p in doc.paragraphs if p.text and p.text.strip()]
        return "\n\n".join(paras)
    except Exception as e:
        print(f"[ERROR] Failed to extract DOCX {docx_path}: {e}")
        return ""

def main():
    TEXT_DIR.mkdir(parents=True, exist_ok=True)

    if not RAW_DIR.exists():
        print(f"[ERROR] RAW_DIR does not exist: {RAW_DIR}")
        return

    files = list(RAW_DIR.glob("*"))
    if not files:
        print(f"[WARNING] No files found in {RAW_DIR}")
        return

    for file_path in files:
        if not file_path.is_file():
            continue

        ext = file_path.suffix.lower()
        output_txt_path = TEXT_DIR / (file_path.stem + ".txt")

        if ext == ".pdf":
            print(f"Extracting from PDF: {file_path.name}")
            text = extract_text_from_pdf(file_path)
        elif ext == ".docx":
            print(f"Extracting from DOCX: {file_path.name}")
            text = extract_text_from_docx(file_path)
        else:
            print(f"[SKIP] Unsupported file type: {file_path.name}")
            continue

        if text.strip():
            output_txt_path.write_text(text, encoding="utf-8")
            print(f"[OK] Saved to {output_txt_path}")
        else:
            print(f"[WARNING] No text extracted from {file_path.name}")

if __name__ == "__main__":
    main()
